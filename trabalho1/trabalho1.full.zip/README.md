# img-proc
Trabalhos da disciplina de Processamento de Imagens.
